// Written by Simon Cahill
// Copyright (c) 2016
// All Right Reserved
// Copies and modifications of this file are prohibited and punishable by law,
// unless done with EXPRESS PERMISSION by the author of this file.

#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED



#endif // MAIN_H_INCLUDED
